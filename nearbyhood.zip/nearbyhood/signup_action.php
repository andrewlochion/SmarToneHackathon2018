<?php
		
	// Get Data
	$resident_ID = $_GET['resident_ID'];
	$username = $_GET['username'];
	$gender = $_GET['gender'];
	$age = $_GET['age'];
	
	if (isset($_GET['pets'])) {
		$pets = 1;
	}
	else{
		$pets = 0;
	}
	
	if (isset($_GET['sports'])) {
		$sports = 1;
	}
	else{
		$sports = 0;
	}
	
	if (isset($_GET['travel'])) {
		$travel = 1;
	}
	else{
		$travel = 0;
	}
	
	if (isset($_GET['celebrities'])) {
		$celebrities = 1;
	}
	else{
		$celebrities = 0;
	}
	
	if (isset($_GET['finance'])) {
		$finance = 1;
	}
	else{
		$finance = 0;
	}
	
	if (isset($_GET['infant_care'])) {
		$infant_care = 1;
	}
	else{
		$infant_care = 0;
	}
	
	if (isset($_GET['food'])) {
		$food = 1;
	}
	else{
		$food = 0;
	}
	
	if (isset($_GET['music'])) {
		$music = 1;
	}
	else{
		$music = 0;
	}
	
	if (isset($_GET['technology'])) {
		$technology = 1;
	}
	else{
		$technology = 0;
	}
	
	if (isset($_GET['games'])) {
		$games = 1;
	}
	else{
		$games = 0;
	}
	
	//echo $residentialID.",".$pets.",".$sports.",".$travel.",".$celebrity.",".$finance.",".$infant_care.",".$food.",".$music.",".$technology.",".$games;
	//$interests = array($pets,$sports,$travel,$celebrity,$finance,$infant_care,$food,$music,$technology,$games);
	
	//$interests = print_r($interests, true);
	//echo $residentialID." + ".$interests;
	
	$con = mysqli_connect("localhost", "root", "leungjef1", "test");
	if(mysqli_connect_errno()) {
		die("Fail to create resident information: ".mysqli_connect_error());
	}
	else {
		
		$sqli = "
			INSERT INTO resident_info (
				resident_ID, username, gender, age
			)
			VALUES
			('$resident_ID', '$username', '$gender', '$age')
		";		
		mysqli_query($con, $sqli);
		
		$sqli = "
			INSERT INTO resident_interest (
				resident_ID, pets, sports, travel, celebrities, finance, infant_care, food, music, technology, games
			)
			VALUES
			('$resident_ID', '$pets', '$sports', '$travel', '$celebrities', '$finance', '$infant_care', '$food', '$music', '$technology', '$games')
		";		
		mysqli_query($con, $sqli);
		
		echo "Create resident information successfully.";
		
		$cookie_name = "resident_ID";
		$cookie_value = $resident_ID;
		setcookie($cookie_name, $cookie_value, time() + (60 * 5));
		
		if(!isset($_COOKIE[$cookie_name])) {
			 echo "Cookie named '" . $cookie_name . "' is not set!";
		} else {
			 echo "Cookie '" . $cookie_name . "' is set!<br>";
			 echo "Value is: " . $_COOKIE[$cookie_name];
		}
		
		header("Location: index2.php");
		exit();
	}
?>